<?php

namespace App\Filament\Pages;

use Filament\Pages\Page;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\DateTimePicker;
use App\Models\Reservation;
use App\Models\Patient;
use App\Models\Doctor;
use App\Models\Service;
use Filament\Notifications\Notification;
use Illuminate\Support\Carbon;

class ManageReservations extends Page implements Forms\Contracts\HasForms
{
    use Forms\Concerns\InteractsWithForms;

    protected static string $view = 'filament.pages.manage-reservations';
    protected static ?string $title = 'إدارة الحجوزات';
    protected static ?string $navigationGroup = 'الحجوزات';
    

    public ?Patient $selectedPatient = null;
    public ?Doctor $selectedDoctor = null;
    public $showPatientModal = false;
    public $showDoctorModal = false;
    public $showWaitingCountModal = false;

    public $searchName;
    public $searchFrom;
    public $searchTo;
    public $searchDate;
    public $reservations = [];
    public $waitingCount = 0;

    public $patient_id;
    public $name;
    public $phone;
    public $address;
    public $doctor_id;
    public $service_id;
    public $price;
    public $reservation_date;

    public function mount()
    {
        $this->searchDate = now()->toDateString();
        $this->loadReservations();
    }

    public function loadReservations()
    {
        $query = Reservation::with(['patient', 'doctor']);

        if ($this->searchName) {
            $query->whereHas('patient', function ($q) {
                $q->where('name', 'like', "%{$this->searchName}%")
                    ->orWhere('phone', 'like', "%{$this->searchName}%");
            });
        }

        if ($this->searchDate) {
            $query->whereDate('reservation_date', $this->searchDate);
        }

        if ($this->searchFrom && $this->searchTo) {
            $query->whereBetween('reservation_date', [$this->searchFrom, $this->searchTo]);
        }

        $this->reservations = $query->orderBy('reservation_number')->get();
    }

    public function showPatient($id)
    {
        $this->selectedPatient = Patient::find($id);
        $this->showPatientModal = true;
    }

    public function showDoctor($id)
    {
        $this->selectedDoctor = Doctor::find($id);
        $this->showDoctorModal = true;
    }

    public function showWaitingCount($id)
    {
        $reservation = Reservation::with(['patient', 'doctor'])->find($id);

        if ($reservation) {
            $this->waitingCount = Reservation::whereDate('reservation_date', $reservation->reservation_date)
                ->where('status', 'pending')
                ->where('reservation_number', '<', $reservation->reservation_number)
                ->count();
            
            $this->showWaitingCountModal = true;
            // Notification::make()
            //     ->title("متبقي على الدور: {$this->waitingCount}")
            //     ->success()
            //     ->send();
        }
    }

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('بيانات المريض')
                    ->schema([
                        Select::make('patient_id')
                            ->label('بحث عن مريض (اسم أو رقم هاتف)')
                            ->searchable()
                            ->getSearchResultsUsing(fn(string $search) => Patient::query()
                                ->where('name', 'like', "%{$search}%")
                                ->orWhere('phone', 'like', "%{$search}%")
                                ->limit(10)
                                ->pluck('name', 'id')
                                ->toArray())
                            ->live(onBlur: false)
                            ->reactive()
                            ->afterStateUpdated(function ($state, $set) {
                                if ($state) {
                                    $patient = Patient::find($state);
                                    if ($patient) {
                                        $set('name', $patient->name);
                                        $set('phone', $patient->phone);
                                        $set('address', $patient->address);
                                    }
                                }
                            }),
                        Forms\Components\Grid::make(3)->schema([
                            TextInput::make('name')->label('اسم المريض')->required(),
                            TextInput::make('phone')->label('رقم الهاتف')->required(),
                            TextInput::make('address')->label('العنوان'),
                        ]),
                    ]),
                Forms\Components\Section::make('بيانات الحجز')
                    ->schema([
                        DateTimePicker::make('reservation_date')->label('تاريخ الحجز')->default(now())->required(),
                    ]),
                Forms\Components\Section::make('الخدمة')
                    ->schema([
                        Forms\Components\Grid::make(2)->schema([
                            Select::make('doctor_id')
                                ->label('اختر الطبيب')
                                ->options(Doctor::pluck('name', 'id'))
                                ->required()
                                ->searchable()
                                ->reactive(),
                            Select::make('service_id')
                                ->label('اختر الخدمة')
                                ->options(fn($get) => $get('doctor_id')
                                    ? Service::where('doctor_id', $get('doctor_id'))->pluck('name', 'id')
                                    : [])
                                ->required()
                                ->reactive()
                                ->afterStateUpdated(function ($state, $set) {
                                    if ($state) {
                                        $service = Service::find($state);
                                        if ($service) {
                                            $set('price', $service->price);
                                        }
                                    }
                                }),
                        ]),
                        TextInput::make('price')->label('سعر الخدمة')->disabled()->dehydrated(true),
                    ]),
            ]);
    }

    public function create(): void
    {
        $this->validate([
            'name' => 'required|string',
            'phone' => 'required|string',
            'doctor_id' => 'required|exists:doctors,id',
            'service_id' => 'required|exists:services,id',
            'reservation_date' => 'required|date',
        ]);

        $patient = Patient::where('phone', $this->phone)
            ->orWhere('name', $this->name)
            ->first();

        if (!$patient) {
            $patient = Patient::create([
                'name' => $this->name,
                'phone' => $this->phone,
                'address' => $this->address,
            ]);
        }

        $reservationNumber = Reservation::whereDate('reservation_date', Carbon::parse($this->reservation_date)->toDateString())
            ->max('reservation_number') + 1;

        Reservation::create([
            'patient_id' => $patient->id,
            'doctor_id' => $this->doctor_id,
            'service_id' => $this->service_id,
            'service_price' => $this->price,
            'status' => 'pending',
            'reservation_date' => $this->reservation_date,
            'reservation_number' => $reservationNumber,
        ]);

        $this->reset(['patient_id', 'name', 'phone', 'address', 'doctor_id', 'service_id', 'price', 'reservation_date']);
        $this->loadReservations();

        Notification::make()
            ->title('تم حفظ الحجز بنجاح')
            ->success()
            ->send();
    }

    public function updateStatus($id, $status)
    {
        $reservation = Reservation::find($id);
        if ($reservation) {
            $reservation->update(['status' => $status]);
            $this->loadReservations();
        }
    }
}
