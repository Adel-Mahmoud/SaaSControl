<?php

namespace App\Filament\Pages;

use Filament\Pages\Page;

class TestPage extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-document-text';
    protected static ?string $navigationLabel = 'صفحة اختبارية';
    protected static ?string $title = 'الصفحة الاختبارية';
    protected static ?string $navigationGroup = 'الإدارة';
    protected static string $view = 'filament.pages.settings';

    public static function getNavigationSort(): ?int
    {
        return 1;
    }
}