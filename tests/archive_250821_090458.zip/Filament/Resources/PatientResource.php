<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PatientResource\Pages;
use App\Models\Patient;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Navigation\NavigationItem;

class PatientResource extends Resource
{
    protected static ?string $model = Patient::class;
    // protected static ?string $navigationIcon = 'heroicon-o-user';
    protected static ?string $navigationGroup = 'المرضى';
    protected static ?int $navigationSort = 2;
    protected static ?string $slug = 'patients';
    protected static ?string $navigationLabel = 'المرضى';
    protected static ?string $pluralModelLabel = 'المرضى';
    protected static ?string $modelLabel = 'مريض';

    public static function getNavigationItems(): array
    {
        return [
            NavigationItem::make()
                ->label('عرض الكل')
                ->url(static::getUrl('index'))
                ->group(static::getNavigationGroup())
                ->sort(0),

            NavigationItem::make()
                ->label('إنشاء جديد')
                ->url(static::getUrl('create'))
                ->group(static::getNavigationGroup())
                ->sort(1),
        ];
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('تفاصيل المريض')
                ->description('قم بتعبئة تفاصيل المريض الأساسية')
                ->schema([
                    Forms\Components\TextInput::make('name')
                        ->label('اسم المريض')
                        ->required()
                        ->maxLength(255),

                    Forms\Components\TextInput::make('phone')
                        ->label('رقم الهاتف')
                        ->required()
                        ->tel()
                        ->maxLength(20),

                    Forms\Components\TextInput::make('address')
                        ->label('عنوان المريض')
                        ->maxLength(500)
                        ->columnSpanFull(),
                ])
                ->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->label('اسم المريض')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('phone')
                    ->label('رقم الهاتف')
                    ->searchable(),

                Tables\Columns\TextColumn::make('address')
                    ->label('عنوان المريض')
                    ->toggleable(isToggledHiddenByDefault: true),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('تاريخ الإنشاء')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->actions([
                Tables\Actions\EditAction::make()->label('تعديل'),
                Tables\Actions\DeleteAction::make()->label('حذف'),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make()->label('حذف المحدد'),
                ]),
            ])
            ->defaultSort('id', 'desc');
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPatients::route('/'),
            'create' => Pages\CreatePatient::route('/create'),
            'edit' => Pages\EditPatient::route('/{record}/edit'),
        ];
    }
}
