<x-filament-panels::page>
    <div class="p-6 bg-white rounded-lg shadow-md">
        <h1 class="text-2xl font-bold text-gray-800 mb-4">التقارير</h1>
        <p class="text-gray-600">هذه صفحة التقارير الخاصة بالحجوزات.</p>
        
        <div class="mt-6 p-4 bg-green-50 border border-green-200 rounded">
            <h3 class="text-lg font-semibold text-green-800">معلومات الصفحة:</h3>
            <ul class="list-disc list-inside mt-2 text-green-700">
                <li>المجموعة: الحجوزات</li>
                <li>الأيقونة: heroicon-o-chart-bar</li>
                <li>نوع الصفحة: تقارير</li>
            </ul>
        </div>
    </div>
</x-filament-panels::page>