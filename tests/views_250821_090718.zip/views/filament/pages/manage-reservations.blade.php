<x-filament::page>
    <div class="grid grid-cols-1 md:grid-cols-1 gap-6">
        <div class="p-4 bg-white dark:bg-gray-900 shadow rounded">
            {{ $this->form }}
            <x-filament::button wire:click="create" class="mt-6">
                إضافة الحجز
            </x-filament::button>
        </div>
    </div>

    <div class="mt-6 bg-white dark:bg-gray-900 p-6 rounded border border-gray-200 dark:border-gray-700">
        <h3 class="text-xl font-bold mb-6 text-indigo-700 dark:text-indigo-400 flex items-center gap-2">
            <x-heroicon-o-magnifying-glass class="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            البحث المتقدم
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <input type="text" wire:model.defer="searchName"
                   placeholder="ادخل اسم المريض أو الهاتف"
                   class="rounded-lg border-gray-300 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 bg-white dark:bg-gray-800 dark:text-gray-200">
            <input type="date" wire:model.defer="searchDate"
                   class="rounded-lg border-gray-300 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 bg-white dark:bg-gray-800 dark:text-gray-200">
            <input type="date" wire:model.defer="searchFrom"
                   class="rounded-lg border-gray-300 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 bg-white dark:bg-gray-800 dark:text-gray-200">
            <input type="date" wire:model.defer="searchTo"
                   class="rounded-lg border-gray-300 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 bg-white dark:bg-gray-800 dark:text-gray-200">
        </div>

        <div class="mt-6 flex gap-3 justify-start">
            <x-filament::button wire:click="loadReservations">
                بحث
            </x-filament::button>
        </div>
    </div>

    <div class="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        @foreach ($this->reservations as $reservation)
            @php
                $waiting = \App\Models\Reservation::whereDate('reservation_date', $reservation->reservation_date)
                    ->where('status','pending')
                    ->where('reservation_number','<',$reservation->reservation_number)
                    ->count();
            @endphp

            <div class="p-4 bg-white dark:bg-gray-900 shadow rounded border border-gray-200 dark:border-gray-700 hover:shadow-lg transition">
                <div class="font-bold text-lg cursor-pointer text-blue-600 dark:text-blue-400"
                     wire:click="showPatient({{ $reservation->patient->id }})">
                    {{ $reservation->patient->name }}
                </div>
                <div class="text-sm text-gray-600 dark:text-gray-300 cursor-pointer text-blue-600 dark:text-blue-400"
                     wire:click="showDoctor({{ $reservation->doctor->id }})">
                    دكتور: {{ $reservation->doctor->name }}
                </div>

                <div class="mt-2 dark:text-gray-300">
                    الدور: {{ $reservation->reservation_number }}
                </div>

                @if($reservation->status == 'pending')
                    <div class="mt-1 dark:text-gray-300">المتبقي على الدور: {{ $waiting }}</div>
                @endif

                <div class="mt-2 flex items-center space-x-2 dark:text-gray-300">
                    <span>الحالة:</span>
                    <select wire:change="updateStatus({{ $reservation->id }}, $event.target.value)"
                            class="border rounded px-2 py-1 text-sm bg-white dark:bg-gray-800 dark:border-gray-600 dark:text-gray-200">
                        <option value="pending"   @selected($reservation->status == 'pending')>قيد الانتظار</option>
                        <option value="completad" @selected($reservation->status == 'completad')>مؤكد</option>
                        <option value="cancelled" @selected($reservation->status == 'cancelled')>ملغي</option>
                    </select>
                </div>
            </div>
        @endforeach
    </div>

    <!-- Patient Modal -->
    <div 
        x-show="$wire.showPatientModal" 
        class="fixed inset-0 z-50 flex items-center justify-center"
        style="display: none;"
    >
        <div class="absolute inset-0 bg-black/50"></div>
        <div class="relative bg-white dark:bg-gray-900 w-full max-w-md mx-auto rounded-2xl shadow-xl p-6">
            <h2 class="text-xl font-bold mb-4 text-gray-800 dark:text-gray-200">بيانات المريض</h2>
            @if($selectedPatient)
                <div class="space-y-2 text-gray-700 dark:text-gray-300">
                    <p><span class="font-semibold">الاسم:</span> {{ $selectedPatient->name }}</p>
                    <p><span class="font-semibold">الهاتف:</span> {{ $selectedPatient->phone }}</p>
                    <p><span class="font-semibold">العنوان:</span> {{ $selectedPatient->address }}</p>
                </div>
            @endif
            <div class="mt-6 text-right">
                <x-filament::button color="gray" wire:click="$set('showPatientModal', false)">إغلاق</x-filament::button>
            </div>
        </div>
    </div>

    <!-- Doctor Modal -->
    <div 
        x-show="$wire.showDoctorModal" 
        class="fixed inset-0 z-50 flex items-center justify-center"
        style="display: none;"
    >
        <div class="absolute inset-0 bg-black/50"></div>
        <div class="relative bg-white dark:bg-gray-900 w-full max-w-md mx-auto rounded-2xl shadow-xl p-6">
            <h2 class="text-xl font-bold mb-4 text-gray-800 dark:text-gray-200">بيانات الدكتور</h2>
            @if($selectedDoctor)
                <div class="space-y-2 text-gray-700 dark:text-gray-300">
                    <p><span class="font-semibold">الاسم:</span> {{ $selectedDoctor->name }}</p>
                    <p><span class="font-semibold">التخصص:</span> {{ $selectedDoctor->specialization }}</p>
                </div>
            @endif
            <div class="mt-6 text-right">
                <x-filament::button color="gray" wire:click="$set('showDoctorModal', false)">إغلاق</x-filament::button>
            </div>
        </div>
    </div>
</x-filament::page>
